﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.DTOs
{
    public class TokenRequest
    {
        public string RefreshToken { get; set; }
    }
}

